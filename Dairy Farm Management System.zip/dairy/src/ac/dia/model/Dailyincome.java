/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "dailyincome")
@NamedQueries({
    @NamedQuery(name = "Dailyincome.findAll", query = "SELECT d FROM Dailyincome d"),
    @NamedQuery(name = "Dailyincome.findByIddailyIncome", query = "SELECT d FROM Dailyincome d WHERE d.iddailyIncome = :iddailyIncome"),
    @NamedQuery(name = "Dailyincome.findByDate", query = "SELECT d FROM Dailyincome d WHERE d.date = :date"),
    @NamedQuery(name = "Dailyincome.findByType", query = "SELECT d FROM Dailyincome d WHERE d.type = :type"),
    @NamedQuery(name = "Dailyincome.findByAmount", query = "SELECT d FROM Dailyincome d WHERE d.amount = :amount")})
public class Dailyincome implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "iddailyIncome")
    private Integer iddailyIncome;
    @Column(name = "date")
    private String date;
    @Column(name = "type")
    private String type;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "amount")
    private Double amount;

    public Dailyincome() {
    }

    public Dailyincome(Integer iddailyIncome) {
        this.iddailyIncome = iddailyIncome;
    }

    public Integer getIddailyIncome() {
        return iddailyIncome;
    }

    public void setIddailyIncome(Integer iddailyIncome) {
        this.iddailyIncome = iddailyIncome;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iddailyIncome != null ? iddailyIncome.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Dailyincome)) {
            return false;
        }
        Dailyincome other = (Dailyincome) object;
        if ((this.iddailyIncome == null && other.iddailyIncome != null) || (this.iddailyIncome != null && !this.iddailyIncome.equals(other.iddailyIncome))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ac.dia.model.Dailyincome[ iddailyIncome=" + iddailyIncome + " ]";
    }
    
}
