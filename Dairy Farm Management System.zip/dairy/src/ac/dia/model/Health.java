/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "health")
@NamedQueries({
    @NamedQuery(name = "Health.findAll", query = "SELECT h FROM Health h"),
    @NamedQuery(name = "Health.findByIdhealth", query = "SELECT h FROM Health h WHERE h.idhealth = :idhealth"),
    @NamedQuery(name = "Health.findByHealthType", query = "SELECT h FROM Health h WHERE h.healthType = :healthType")})
public class Health implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idhealth")
    private Integer idhealth;
    @Column(name = "healthType")
    private String healthType;

    public Health() {
    }

    public Health(Integer idhealth) {
        this.idhealth = idhealth;
    }

    public Integer getIdhealth() {
        return idhealth;
    }

    public void setIdhealth(Integer idhealth) {
        this.idhealth = idhealth;
    }

    public String getHealthType() {
        return healthType;
    }

    public void setHealthType(String healthType) {
        this.healthType = healthType;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idhealth != null ? idhealth.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Health)) {
            return false;
        }
        Health other = (Health) object;
        if ((this.idhealth == null && other.idhealth != null) || (this.idhealth != null && !this.idhealth.equals(other.idhealth))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return healthType+"-" + idhealth;
    }
    
}
