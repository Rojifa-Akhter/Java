/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "finance")
@NamedQueries({
    @NamedQuery(name = "Finance.findAll", query = "SELECT f FROM Finance f"),
    @NamedQuery(name = "Finance.findByIdfinance", query = "SELECT f FROM Finance f WHERE f.idfinance = :idfinance"),
    @NamedQuery(name = "Finance.findByType", query = "SELECT f FROM Finance f WHERE f.type = :type"),
    @NamedQuery(name = "Finance.findByDate", query = "SELECT f FROM Finance f WHERE f.date = :date"),
    @NamedQuery(name = "Finance.findByExpensesAmount", query = "SELECT f FROM Finance f WHERE f.expensesAmount = :expensesAmount"),
    @NamedQuery(name = "Finance.findByIncomeamount", query = "SELECT f FROM Finance f WHERE f.incomeamount = :incomeamount"),
    @NamedQuery(name = "Finance.findByTotal", query = "SELECT f FROM Finance f WHERE f.total = :total")})
public class Finance implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idfinance")
    private Integer idfinance;
    @Column(name = "type")
    private String type;
    @Column(name = "date")
    private String date;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "expensesAmount")
    private Double expensesAmount;
    @Column(name = "Incomeamount")
    private Double incomeamount;
    @Column(name = "Total")
    private Double total;

    public Finance() {
    }

    public Finance(Integer idfinance) {
        this.idfinance = idfinance;
    }

    public Integer getIdfinance() {
        return idfinance;
    }

    public void setIdfinance(Integer idfinance) {
        this.idfinance = idfinance;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Double getExpensesAmount() {
        return expensesAmount;
    }

    public void setExpensesAmount(Double expensesAmount) {
        this.expensesAmount = expensesAmount;
    }

    public Double getIncomeamount() {
        return incomeamount;
    }

    public void setIncomeamount(Double incomeamount) {
        this.incomeamount = incomeamount;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idfinance != null ? idfinance.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Finance)) {
            return false;
        }
        Finance other = (Finance) object;
        if ((this.idfinance == null && other.idfinance != null) || (this.idfinance != null && !this.idfinance.equals(other.idfinance))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ac.dia.model.Finance[ idfinance=" + idfinance + " ]";
    }
    
}
