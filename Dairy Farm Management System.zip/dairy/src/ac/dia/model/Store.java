/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "store")
@NamedQueries({
    @NamedQuery(name = "Store.findAll", query = "SELECT s FROM Store s"),
    @NamedQuery(name = "Store.findByIdstore", query = "SELECT s FROM Store s WHERE s.idstore = :idstore"),
    @NamedQuery(name = "Store.findByName", query = "SELECT s FROM Store s WHERE s.name = :name"),
    @NamedQuery(name = "Store.findByAddress", query = "SELECT s FROM Store s WHERE s.address = :address"),
    @NamedQuery(name = "Store.findByPdType", query = "SELECT s FROM Store s WHERE s.pdType = :pdType"),
    @NamedQuery(name = "Store.findByPdAvailability", query = "SELECT s FROM Store s WHERE s.pdAvailability = :pdAvailability")})
public class Store implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idstore")
    private Integer idstore;
    @Column(name = "name")
    private String name;
    @Column(name = "address")
    private String address;
    @Column(name = "pdType")
    private String pdType;
    @Column(name = "pdAvailability")
    private String pdAvailability;

    public Store() {
    }

    public Store(Integer idstore) {
        this.idstore = idstore;
    }

    public Integer getIdstore() {
        return idstore;
    }

    public void setIdstore(Integer idstore) {
        this.idstore = idstore;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPdType() {
        return pdType;
    }

    public void setPdType(String pdType) {
        this.pdType = pdType;
    }

    public String getPdAvailability() {
        return pdAvailability;
    }

    public void setPdAvailability(String pdAvailability) {
        this.pdAvailability = pdAvailability;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idstore != null ? idstore.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Store)) {
            return false;
        }
        Store other = (Store) object;
        if ((this.idstore == null && other.idstore != null) || (this.idstore != null && !this.idstore.equals(other.idstore))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ac.dia.model.Store[ idstore=" + idstore + " ]";
    }
    
}
