/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "animal")
@NamedQueries({
    @NamedQuery(name = "Animal.findAll", query = "SELECT a FROM Animal a"),
    @NamedQuery(name = "Animal.findByIdanimal", query = "SELECT a FROM Animal a WHERE a.idanimal = :idanimal"),
    @NamedQuery(name = "Animal.findByAniName", query = "SELECT a FROM Animal a WHERE a.aniName = :aniName"),
    @NamedQuery(name = "Animal.findBySpecies", query = "SELECT a FROM Animal a WHERE a.species = :species"),
    @NamedQuery(name = "Animal.findByType", query = "SELECT a FROM Animal a WHERE a.type = :type"),
    @NamedQuery(name = "Animal.findByColor", query = "SELECT a FROM Animal a WHERE a.color = :color"),
    @NamedQuery(name = "Animal.findByHeight", query = "SELECT a FROM Animal a WHERE a.height = :height"),
    @NamedQuery(name = "Animal.findByWeight", query = "SELECT a FROM Animal a WHERE a.weight = :weight")})
public class Animal implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idanimal")
    private Integer idanimal;
    @Column(name = "aniName")
    private String aniName;
    @Column(name = "species")
    private String species;
    @Column(name = "type")
    private String type;
    @Column(name = "color")
    private String color;
    @Column(name = "height")
    private Integer height;
    @Column(name = "weight")
    private Integer weight;
    @OneToMany(mappedBy = "idanimal")
    private Collection<Medical> medicalCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "animalIdanimal")
    private Collection<Feed> feedCollection;
    @OneToMany(mappedBy = "idanimal")
    private Collection<Milkrecord> milkrecordCollection;

    public Animal() {
    }

    public Animal(Integer idanimal) {
        this.idanimal = idanimal;
    }

    public Integer getIdanimal() {
        return idanimal;
    }

    public void setIdanimal(Integer idanimal) {
        this.idanimal = idanimal;
    }

    public String getAniName() {
        return aniName;
    }

    public void setAniName(String aniName) {
        this.aniName = aniName;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public Collection<Medical> getMedicalCollection() {
        return medicalCollection;
    }

    public void setMedicalCollection(Collection<Medical> medicalCollection) {
        this.medicalCollection = medicalCollection;
    }

    public Collection<Feed> getFeedCollection() {
        return feedCollection;
    }

    public void setFeedCollection(Collection<Feed> feedCollection) {
        this.feedCollection = feedCollection;
    }

    public Collection<Milkrecord> getMilkrecordCollection() {
        return milkrecordCollection;
    }

    public void setMilkrecordCollection(Collection<Milkrecord> milkrecordCollection) {
        this.milkrecordCollection = milkrecordCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idanimal != null ? idanimal.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Animal)) {
            return false;
        }
        Animal other = (Animal) object;
        if ((this.idanimal == null && other.idanimal != null) || (this.idanimal != null && !this.idanimal.equals(other.idanimal))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return " "+ idanimal;
    }
    
}
