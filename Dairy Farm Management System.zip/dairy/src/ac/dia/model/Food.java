/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "food")
@NamedQueries({
    @NamedQuery(name = "Food.findAll", query = "SELECT f FROM Food f"),
    @NamedQuery(name = "Food.findByIdfood", query = "SELECT f FROM Food f WHERE f.idfood = :idfood"),
    @NamedQuery(name = "Food.findByFname", query = "SELECT f FROM Food f WHERE f.fname = :fname"),
    @NamedQuery(name = "Food.findByComponent", query = "SELECT f FROM Food f WHERE f.component = :component"),
    @NamedQuery(name = "Food.findByType", query = "SELECT f FROM Food f WHERE f.type = :type")})
public class Food implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idfood")
    private Integer idfood;
    @Column(name = "fname")
    private String fname;
    @Column(name = "component")
    private String component;
    @Column(name = "type")
    private String type;

    public Food() {
    }

    public Food(Integer idfood) {
        this.idfood = idfood;
    }

    public Integer getIdfood() {
        return idfood;
    }

    public void setIdfood(Integer idfood) {
        this.idfood = idfood;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idfood != null ? idfood.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Food)) {
            return false;
        }
        Food other = (Food) object;
        if ((this.idfood == null && other.idfood != null) || (this.idfood != null && !this.idfood.equals(other.idfood))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return fname+"-" + idfood;
    }
    
}
