/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "milkrecord")
@NamedQueries({
    @NamedQuery(name = "Milkrecord.findAll", query = "SELECT m FROM Milkrecord m"),
    @NamedQuery(name = "Milkrecord.findByIdmilkrecord", query = "SELECT m FROM Milkrecord m WHERE m.idmilkrecord = :idmilkrecord"),
    @NamedQuery(name = "Milkrecord.findByAniName", query = "SELECT m FROM Milkrecord m WHERE m.aniName = :aniName"),
    @NamedQuery(name = "Milkrecord.findByMilkQuantity", query = "SELECT m FROM Milkrecord m WHERE m.milkQuantity = :milkQuantity"),
    @NamedQuery(name = "Milkrecord.findByDate", query = "SELECT m FROM Milkrecord m WHERE m.date = :date")})
public class Milkrecord implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idmilkrecord")
    private Integer idmilkrecord;
    @Column(name = "aniName")
    private String aniName;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "milkQuantity")
    private Double milkQuantity;
    @Column(name = "date")
    private String date;
    @JoinColumn(name = "idanimal", referencedColumnName = "idanimal")
    @ManyToOne
    private Animal idanimal;

    public Milkrecord() {
    }

    public Milkrecord(Integer idmilkrecord) {
        this.idmilkrecord = idmilkrecord;
    }

    public Integer getIdmilkrecord() {
        return idmilkrecord;
    }

    public void setIdmilkrecord(Integer idmilkrecord) {
        this.idmilkrecord = idmilkrecord;
    }

    public String getAniName() {
        return aniName;
    }

    public void setAniName(String aniName) {
        this.aniName = aniName;
    }

    public Double getMilkQuantity() {
        return milkQuantity;
    }

    public void setMilkQuantity(Double milkQuantity) {
        this.milkQuantity = milkQuantity;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Animal getIdanimal() {
        return idanimal;
    }

    public void setIdanimal(Animal idanimal) {
        this.idanimal = idanimal;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idmilkrecord != null ? idmilkrecord.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Milkrecord)) {
            return false;
        }
        Milkrecord other = (Milkrecord) object;
        if ((this.idmilkrecord == null && other.idmilkrecord != null) || (this.idmilkrecord != null && !this.idmilkrecord.equals(other.idmilkrecord))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ac.dia.model.Milkrecord[ idmilkrecord=" + idmilkrecord + " ]";
    }
    
}
