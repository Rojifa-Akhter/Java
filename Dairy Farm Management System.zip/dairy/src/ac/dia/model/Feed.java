/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "feed")
@NamedQueries({
    @NamedQuery(name = "Feed.findAll", query = "SELECT f FROM Feed f"),
    @NamedQuery(name = "Feed.findByIdfeed", query = "SELECT f FROM Feed f WHERE f.idfeed = :idfeed"),
    @NamedQuery(name = "Feed.findByFeedIntake", query = "SELECT f FROM Feed f WHERE f.feedIntake = :feedIntake")})
public class Feed implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idfeed")
    private Integer idfeed;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "feedIntake")
    private Double feedIntake;
    @JoinColumn(name = "animal_idanimal", referencedColumnName = "idanimal")
    @ManyToOne(optional = false)
    private Animal animalIdanimal;
    @JoinColumn(name = "food_idfood", referencedColumnName = "idfood")
    @ManyToOne(optional = false)
    private Food foodIdfood;

    public Feed() {
    }

    public Feed(Integer idfeed) {
        this.idfeed = idfeed;
    }

    public Integer getIdfeed() {
        return idfeed;
    }

    public void setIdfeed(Integer idfeed) {
        this.idfeed = idfeed;
    }

    public Double getFeedIntake() {
        return feedIntake;
    }

    public void setFeedIntake(Double feedIntake) {
        this.feedIntake = feedIntake;
    }

    public Animal getAnimalIdanimal() {
        return animalIdanimal;
    }

    public void setAnimalIdanimal(Animal animalIdanimal) {
        this.animalIdanimal = animalIdanimal;
    }

    public Food getFoodIdfood() {
        return foodIdfood;
    }

    public void setFoodIdfood(Food foodIdfood) {
        this.foodIdfood = foodIdfood;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idfeed != null ? idfeed.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Feed)) {
            return false;
        }
        Feed other = (Feed) object;
        if ((this.idfeed == null && other.idfeed != null) || (this.idfeed != null && !this.idfeed.equals(other.idfeed))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ac.dia.model.Feed[ idfeed=" + idfeed + " ]";
    }
    
}
