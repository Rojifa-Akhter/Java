/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "medical")
@NamedQueries({
    @NamedQuery(name = "Medical.findAll", query = "SELECT m FROM Medical m"),
    @NamedQuery(name = "Medical.findByIdmedical", query = "SELECT m FROM Medical m WHERE m.idmedical = :idmedical"),
    @NamedQuery(name = "Medical.findByName", query = "SELECT m FROM Medical m WHERE m.name = :name"),
    @NamedQuery(name = "Medical.findByDate", query = "SELECT m FROM Medical m WHERE m.date = :date"),
    @NamedQuery(name = "Medical.findByHealth", query = "SELECT m FROM Medical m WHERE m.health = :health"),
    @NamedQuery(name = "Medical.findByTreatment", query = "SELECT m FROM Medical m WHERE m.treatment = :treatment"),
    @NamedQuery(name = "Medical.findByMedicine", query = "SELECT m FROM Medical m WHERE m.medicine = :medicine")})
public class Medical implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idmedical")
    private Integer idmedical;
    @Column(name = "name")
    private String name;
    @Column(name = "date")
    private String date;
    @Column(name = "health")
    private String health;
    @Column(name = "treatment")
    private String treatment;
    @Column(name = "medicine")
    private String medicine;
    @JoinColumn(name = "idanimal", referencedColumnName = "idanimal")
    @ManyToOne
    private Animal idanimal;
    @JoinColumn(name = "idanimalType", referencedColumnName = "idanimalType")
    @ManyToOne
    private Animaltype idanimalType;

    public Medical() {
    }

    public Medical(Integer idmedical) {
        this.idmedical = idmedical;
    }

    public Integer getIdmedical() {
        return idmedical;
    }

    public void setIdmedical(Integer idmedical) {
        this.idmedical = idmedical;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getHealth() {
        return health;
    }

    public void setHealth(String health) {
        this.health = health;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getMedicine() {
        return medicine;
    }

    public void setMedicine(String medicine) {
        this.medicine = medicine;
    }

    public Animal getIdanimal() {
        return idanimal;
    }

    public void setIdanimal(Animal idanimal) {
        this.idanimal = idanimal;
    }

    public Animaltype getIdanimalType() {
        return idanimalType;
    }

    public void setIdanimalType(Animaltype idanimalType) {
        this.idanimalType = idanimalType;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idmedical != null ? idmedical.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Medical)) {
            return false;
        }
        Medical other = (Medical) object;
        if ((this.idmedical == null && other.idmedical != null) || (this.idmedical != null && !this.idmedical.equals(other.idmedical))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ac.dia.model.Medical[ idmedical=" + idmedical + " ]";
    }
    
}
