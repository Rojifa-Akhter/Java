/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "dairyfarm")
@NamedQueries({
    @NamedQuery(name = "Dairyfarm.findAll", query = "SELECT d FROM Dairyfarm d"),
    @NamedQuery(name = "Dairyfarm.findByIddairyFarm", query = "SELECT d FROM Dairyfarm d WHERE d.iddairyFarm = :iddairyFarm"),
    @NamedQuery(name = "Dairyfarm.findByName", query = "SELECT d FROM Dairyfarm d WHERE d.name = :name"),
    @NamedQuery(name = "Dairyfarm.findByAddress", query = "SELECT d FROM Dairyfarm d WHERE d.address = :address")})
public class Dairyfarm implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "iddairyFarm")
    private Integer iddairyFarm;
    @Column(name = "name")
    private String name;
    @Column(name = "address")
    private String address;

    public Dairyfarm() {
    }

    public Dairyfarm(Integer iddairyFarm) {
        this.iddairyFarm = iddairyFarm;
    }

    public Integer getIddairyFarm() {
        return iddairyFarm;
    }

    public void setIddairyFarm(Integer iddairyFarm) {
        this.iddairyFarm = iddairyFarm;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iddairyFarm != null ? iddairyFarm.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Dairyfarm)) {
            return false;
        }
        Dairyfarm other = (Dairyfarm) object;
        if ((this.iddairyFarm == null && other.iddairyFarm != null) || (this.iddairyFarm != null && !this.iddairyFarm.equals(other.iddairyFarm))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ac.dia.model.Dairyfarm[ iddairyFarm=" + iddairyFarm + " ]";
    }
    
}
