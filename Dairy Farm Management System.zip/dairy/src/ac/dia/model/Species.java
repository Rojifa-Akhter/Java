/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "species")
@NamedQueries({
    @NamedQuery(name = "Species.findAll", query = "SELECT s FROM Species s"),
    @NamedQuery(name = "Species.findByIdspecies", query = "SELECT s FROM Species s WHERE s.idspecies = :idspecies"),
    @NamedQuery(name = "Species.findBySpeciesName", query = "SELECT s FROM Species s WHERE s.speciesName = :speciesName"),
    @NamedQuery(name = "Species.findByDescription", query = "SELECT s FROM Species s WHERE s.description = :description")})
public class Species implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idspecies")
    private Integer idspecies;
    @Column(name = "speciesName")
    private String speciesName;
    @Column(name = "Description")
    private String description;
    @JoinColumn(name = "idanimalType", referencedColumnName = "idanimalType")
    @ManyToOne
    private Animaltype idanimalType;

    public Species() {
    }

    public Species(Integer idspecies) {
        this.idspecies = idspecies;
    }

    public Integer getIdspecies() {
        return idspecies;
    }

    public void setIdspecies(Integer idspecies) {
        this.idspecies = idspecies;
    }

    public String getSpeciesName() {
        return speciesName;
    }

    public void setSpeciesName(String speciesName) {
        this.speciesName = speciesName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Animaltype getIdanimalType() {
        return idanimalType;
    }

    public void setIdanimalType(Animaltype idanimalType) {
        this.idanimalType = idanimalType;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idspecies != null ? idspecies.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Species)) {
            return false;
        }
        Species other = (Species) object;
        if ((this.idspecies == null && other.idspecies != null) || (this.idspecies != null && !this.idspecies.equals(other.idspecies))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return speciesName+"-" + idspecies;
    }
    
}
