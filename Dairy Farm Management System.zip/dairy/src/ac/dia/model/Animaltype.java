/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.model;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "animaltype")
@NamedQueries({
    @NamedQuery(name = "Animaltype.findAll", query = "SELECT a FROM Animaltype a"),
    @NamedQuery(name = "Animaltype.findByIdanimalType", query = "SELECT a FROM Animaltype a WHERE a.idanimalType = :idanimalType"),
    @NamedQuery(name = "Animaltype.findByAtypeName", query = "SELECT a FROM Animaltype a WHERE a.atypeName = :atypeName"),
    @NamedQuery(name = "Animaltype.findByDescription", query = "SELECT a FROM Animaltype a WHERE a.description = :description")})
public class Animaltype implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idanimalType")
    private Integer idanimalType;
    @Column(name = "atypeName")
    private String atypeName;
    @Column(name = "description")
    private String description;
    @OneToMany(mappedBy = "idanimalType")
    private Collection<Medical> medicalCollection;
    @OneToMany(mappedBy = "idanimalType")
    private Collection<Species> speciesCollection;

    public Animaltype() {
    }

    public Animaltype(Integer idanimalType) {
        this.idanimalType = idanimalType;
    }

    public Integer getIdanimalType() {
        return idanimalType;
    }

    public void setIdanimalType(Integer idanimalType) {
        this.idanimalType = idanimalType;
    }

    public String getAtypeName() {
        return atypeName;
    }

    public void setAtypeName(String atypeName) {
        this.atypeName = atypeName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Collection<Medical> getMedicalCollection() {
        return medicalCollection;
    }

    public void setMedicalCollection(Collection<Medical> medicalCollection) {
        this.medicalCollection = medicalCollection;
    }

    public Collection<Species> getSpeciesCollection() {
        return speciesCollection;
    }

    public void setSpeciesCollection(Collection<Species> speciesCollection) {
        this.speciesCollection = speciesCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idanimalType != null ? idanimalType.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Animaltype)) {
            return false;
        }
        Animaltype other = (Animaltype) object;
        if ((this.idanimalType == null && other.idanimalType != null) || (this.idanimalType != null && !this.idanimalType.equals(other.idanimalType))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return atypeName+"-" + idanimalType;
    }
    
}
