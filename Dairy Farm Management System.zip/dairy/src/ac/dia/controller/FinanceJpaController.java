/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.controller;

import ac.dia.controller.exceptions.NonexistentEntityException;
import ac.dia.controller.exceptions.PreexistingEntityException;
import ac.dia.model.Finance;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author HP
 */
public class FinanceJpaController implements Serializable {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("dairyPU");
        EntityManager em = emf.createEntityManager();

    public FinanceJpaController() {
        
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Finance finance) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(finance);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findFinance(finance.getIdfinance()) != null) {
                throw new PreexistingEntityException("Finance " + finance + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Finance finance) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            finance = em.merge(finance);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = finance.getIdfinance();
                if (findFinance(id) == null) {
                    throw new NonexistentEntityException("The finance with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Finance finance;
            try {
                finance = em.getReference(Finance.class, id);
                finance.getIdfinance();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The finance with id " + id + " no longer exists.", enfe);
            }
            em.remove(finance);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Finance> findFinanceEntities() {
        return findFinanceEntities(true, -1, -1);
    }

    public List<Finance> findFinanceEntities(int maxResults, int firstResult) {
        return findFinanceEntities(false, maxResults, firstResult);
    }

    private List<Finance> findFinanceEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Finance.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Finance findFinance(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Finance.class, id);
        } finally {
            em.close();
        }
    }

    public int getFinanceCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Finance> rt = cq.from(Finance.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
