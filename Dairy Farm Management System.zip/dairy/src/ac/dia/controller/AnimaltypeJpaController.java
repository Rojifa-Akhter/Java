/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.controller;

import ac.dia.controller.exceptions.NonexistentEntityException;
import ac.dia.controller.exceptions.PreexistingEntityException;
import ac.dia.model.Animaltype;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ac.dia.model.Medical;
import java.util.ArrayList;
import java.util.Collection;
import ac.dia.model.Species;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author HP
 */
public class AnimaltypeJpaController implements Serializable {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("dairyPU");
        EntityManager em = emf.createEntityManager();

    public AnimaltypeJpaController() {

    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Animaltype animaltype) throws PreexistingEntityException, Exception {
        if (animaltype.getMedicalCollection() == null) {
            animaltype.setMedicalCollection(new ArrayList<Medical>());
        }
        if (animaltype.getSpeciesCollection() == null) {
            animaltype.setSpeciesCollection(new ArrayList<Species>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Medical> attachedMedicalCollection = new ArrayList<Medical>();
            for (Medical medicalCollectionMedicalToAttach : animaltype.getMedicalCollection()) {
                medicalCollectionMedicalToAttach = em.getReference(medicalCollectionMedicalToAttach.getClass(), medicalCollectionMedicalToAttach.getIdmedical());
                attachedMedicalCollection.add(medicalCollectionMedicalToAttach);
            }
            animaltype.setMedicalCollection(attachedMedicalCollection);
            Collection<Species> attachedSpeciesCollection = new ArrayList<Species>();
            for (Species speciesCollectionSpeciesToAttach : animaltype.getSpeciesCollection()) {
                speciesCollectionSpeciesToAttach = em.getReference(speciesCollectionSpeciesToAttach.getClass(), speciesCollectionSpeciesToAttach.getIdspecies());
                attachedSpeciesCollection.add(speciesCollectionSpeciesToAttach);
            }
            animaltype.setSpeciesCollection(attachedSpeciesCollection);
            em.persist(animaltype);
            for (Medical medicalCollectionMedical : animaltype.getMedicalCollection()) {
                Animaltype oldIdanimalTypeOfMedicalCollectionMedical = medicalCollectionMedical.getIdanimalType();
                medicalCollectionMedical.setIdanimalType(animaltype);
                medicalCollectionMedical = em.merge(medicalCollectionMedical);
                if (oldIdanimalTypeOfMedicalCollectionMedical != null) {
                    oldIdanimalTypeOfMedicalCollectionMedical.getMedicalCollection().remove(medicalCollectionMedical);
                    oldIdanimalTypeOfMedicalCollectionMedical = em.merge(oldIdanimalTypeOfMedicalCollectionMedical);
                }
            }
            for (Species speciesCollectionSpecies : animaltype.getSpeciesCollection()) {
                Animaltype oldIdanimalTypeOfSpeciesCollectionSpecies = speciesCollectionSpecies.getIdanimalType();
                speciesCollectionSpecies.setIdanimalType(animaltype);
                speciesCollectionSpecies = em.merge(speciesCollectionSpecies);
                if (oldIdanimalTypeOfSpeciesCollectionSpecies != null) {
                    oldIdanimalTypeOfSpeciesCollectionSpecies.getSpeciesCollection().remove(speciesCollectionSpecies);
                    oldIdanimalTypeOfSpeciesCollectionSpecies = em.merge(oldIdanimalTypeOfSpeciesCollectionSpecies);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findAnimaltype(animaltype.getIdanimalType()) != null) {
                throw new PreexistingEntityException("Animaltype " + animaltype + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Animaltype animaltype) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Animaltype persistentAnimaltype = em.find(Animaltype.class, animaltype.getIdanimalType());
            Collection<Medical> medicalCollectionOld = persistentAnimaltype.getMedicalCollection();
            Collection<Medical> medicalCollectionNew = animaltype.getMedicalCollection();
            Collection<Species> speciesCollectionOld = persistentAnimaltype.getSpeciesCollection();
            Collection<Species> speciesCollectionNew = animaltype.getSpeciesCollection();
            Collection<Medical> attachedMedicalCollectionNew = new ArrayList<Medical>();
            for (Medical medicalCollectionNewMedicalToAttach : medicalCollectionNew) {
                medicalCollectionNewMedicalToAttach = em.getReference(medicalCollectionNewMedicalToAttach.getClass(), medicalCollectionNewMedicalToAttach.getIdmedical());
                attachedMedicalCollectionNew.add(medicalCollectionNewMedicalToAttach);
            }
            medicalCollectionNew = attachedMedicalCollectionNew;
            animaltype.setMedicalCollection(medicalCollectionNew);
            Collection<Species> attachedSpeciesCollectionNew = new ArrayList<Species>();
            for (Species speciesCollectionNewSpeciesToAttach : speciesCollectionNew) {
                speciesCollectionNewSpeciesToAttach = em.getReference(speciesCollectionNewSpeciesToAttach.getClass(), speciesCollectionNewSpeciesToAttach.getIdspecies());
                attachedSpeciesCollectionNew.add(speciesCollectionNewSpeciesToAttach);
            }
            speciesCollectionNew = attachedSpeciesCollectionNew;
            animaltype.setSpeciesCollection(speciesCollectionNew);
            animaltype = em.merge(animaltype);
            for (Medical medicalCollectionOldMedical : medicalCollectionOld) {
                if (!medicalCollectionNew.contains(medicalCollectionOldMedical)) {
                    medicalCollectionOldMedical.setIdanimalType(null);
                    medicalCollectionOldMedical = em.merge(medicalCollectionOldMedical);
                }
            }
            for (Medical medicalCollectionNewMedical : medicalCollectionNew) {
                if (!medicalCollectionOld.contains(medicalCollectionNewMedical)) {
                    Animaltype oldIdanimalTypeOfMedicalCollectionNewMedical = medicalCollectionNewMedical.getIdanimalType();
                    medicalCollectionNewMedical.setIdanimalType(animaltype);
                    medicalCollectionNewMedical = em.merge(medicalCollectionNewMedical);
                    if (oldIdanimalTypeOfMedicalCollectionNewMedical != null && !oldIdanimalTypeOfMedicalCollectionNewMedical.equals(animaltype)) {
                        oldIdanimalTypeOfMedicalCollectionNewMedical.getMedicalCollection().remove(medicalCollectionNewMedical);
                        oldIdanimalTypeOfMedicalCollectionNewMedical = em.merge(oldIdanimalTypeOfMedicalCollectionNewMedical);
                    }
                }
            }
            for (Species speciesCollectionOldSpecies : speciesCollectionOld) {
                if (!speciesCollectionNew.contains(speciesCollectionOldSpecies)) {
                    speciesCollectionOldSpecies.setIdanimalType(null);
                    speciesCollectionOldSpecies = em.merge(speciesCollectionOldSpecies);
                }
            }
            for (Species speciesCollectionNewSpecies : speciesCollectionNew) {
                if (!speciesCollectionOld.contains(speciesCollectionNewSpecies)) {
                    Animaltype oldIdanimalTypeOfSpeciesCollectionNewSpecies = speciesCollectionNewSpecies.getIdanimalType();
                    speciesCollectionNewSpecies.setIdanimalType(animaltype);
                    speciesCollectionNewSpecies = em.merge(speciesCollectionNewSpecies);
                    if (oldIdanimalTypeOfSpeciesCollectionNewSpecies != null && !oldIdanimalTypeOfSpeciesCollectionNewSpecies.equals(animaltype)) {
                        oldIdanimalTypeOfSpeciesCollectionNewSpecies.getSpeciesCollection().remove(speciesCollectionNewSpecies);
                        oldIdanimalTypeOfSpeciesCollectionNewSpecies = em.merge(oldIdanimalTypeOfSpeciesCollectionNewSpecies);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = animaltype.getIdanimalType();
                if (findAnimaltype(id) == null) {
                    throw new NonexistentEntityException("The animaltype with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Animaltype animaltype;
            try {
                animaltype = em.getReference(Animaltype.class, id);
                animaltype.getIdanimalType();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The animaltype with id " + id + " no longer exists.", enfe);
            }
            Collection<Medical> medicalCollection = animaltype.getMedicalCollection();
            for (Medical medicalCollectionMedical : medicalCollection) {
                medicalCollectionMedical.setIdanimalType(null);
                medicalCollectionMedical = em.merge(medicalCollectionMedical);
            }
            Collection<Species> speciesCollection = animaltype.getSpeciesCollection();
            for (Species speciesCollectionSpecies : speciesCollection) {
                speciesCollectionSpecies.setIdanimalType(null);
                speciesCollectionSpecies = em.merge(speciesCollectionSpecies);
            }
            em.remove(animaltype);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Animaltype> findAnimaltypeEntities() {
        return findAnimaltypeEntities(true, -1, -1);
    }

    public List<Animaltype> findAnimaltypeEntities(int maxResults, int firstResult) {
        return findAnimaltypeEntities(false, maxResults, firstResult);
    }

    private List<Animaltype> findAnimaltypeEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Animaltype.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Animaltype findAnimaltype(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Animaltype.class, id);
        } finally {
            em.close();
        }
    }

    public int getAnimaltypeCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Animaltype> rt = cq.from(Animaltype.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
