/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.controller;

import ac.dia.controller.exceptions.NonexistentEntityException;
import ac.dia.controller.exceptions.PreexistingEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ac.dia.model.Animal;
import ac.dia.model.Animaltype;
import ac.dia.model.Medical;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author HP
 */
public class MedicalJpaController implements Serializable {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("dairyPU");
        EntityManager em = emf.createEntityManager();

    public MedicalJpaController() {
        
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Medical medical) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Animal idanimal = medical.getIdanimal();
            if (idanimal != null) {
                idanimal = em.getReference(idanimal.getClass(), idanimal.getIdanimal());
                medical.setIdanimal(idanimal);
            }
            Animaltype idanimalType = medical.getIdanimalType();
            if (idanimalType != null) {
                idanimalType = em.getReference(idanimalType.getClass(), idanimalType.getIdanimalType());
                medical.setIdanimalType(idanimalType);
            }
            em.persist(medical);
            if (idanimal != null) {
                idanimal.getMedicalCollection().add(medical);
                idanimal = em.merge(idanimal);
            }
            if (idanimalType != null) {
                idanimalType.getMedicalCollection().add(medical);
                idanimalType = em.merge(idanimalType);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findMedical(medical.getIdmedical()) != null) {
                throw new PreexistingEntityException("Medical " + medical + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Medical medical) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Medical persistentMedical = em.find(Medical.class, medical.getIdmedical());
            Animal idanimalOld = persistentMedical.getIdanimal();
            Animal idanimalNew = medical.getIdanimal();
            Animaltype idanimalTypeOld = persistentMedical.getIdanimalType();
            Animaltype idanimalTypeNew = medical.getIdanimalType();
            if (idanimalNew != null) {
                idanimalNew = em.getReference(idanimalNew.getClass(), idanimalNew.getIdanimal());
                medical.setIdanimal(idanimalNew);
            }
            if (idanimalTypeNew != null) {
                idanimalTypeNew = em.getReference(idanimalTypeNew.getClass(), idanimalTypeNew.getIdanimalType());
                medical.setIdanimalType(idanimalTypeNew);
            }
            medical = em.merge(medical);
            if (idanimalOld != null && !idanimalOld.equals(idanimalNew)) {
                idanimalOld.getMedicalCollection().remove(medical);
                idanimalOld = em.merge(idanimalOld);
            }
            if (idanimalNew != null && !idanimalNew.equals(idanimalOld)) {
                idanimalNew.getMedicalCollection().add(medical);
                idanimalNew = em.merge(idanimalNew);
            }
            if (idanimalTypeOld != null && !idanimalTypeOld.equals(idanimalTypeNew)) {
                idanimalTypeOld.getMedicalCollection().remove(medical);
                idanimalTypeOld = em.merge(idanimalTypeOld);
            }
            if (idanimalTypeNew != null && !idanimalTypeNew.equals(idanimalTypeOld)) {
                idanimalTypeNew.getMedicalCollection().add(medical);
                idanimalTypeNew = em.merge(idanimalTypeNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = medical.getIdmedical();
                if (findMedical(id) == null) {
                    throw new NonexistentEntityException("The medical with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Medical medical;
            try {
                medical = em.getReference(Medical.class, id);
                medical.getIdmedical();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The medical with id " + id + " no longer exists.", enfe);
            }
            Animal idanimal = medical.getIdanimal();
            if (idanimal != null) {
                idanimal.getMedicalCollection().remove(medical);
                idanimal = em.merge(idanimal);
            }
            Animaltype idanimalType = medical.getIdanimalType();
            if (idanimalType != null) {
                idanimalType.getMedicalCollection().remove(medical);
                idanimalType = em.merge(idanimalType);
            }
            em.remove(medical);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Medical> findMedicalEntities() {
        return findMedicalEntities(true, -1, -1);
    }

    public List<Medical> findMedicalEntities(int maxResults, int firstResult) {
        return findMedicalEntities(false, maxResults, firstResult);
    }

    private List<Medical> findMedicalEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Medical.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Medical findMedical(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Medical.class, id);
        } finally {
            em.close();
        }
    }

    public int getMedicalCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Medical> rt = cq.from(Medical.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
