/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.controller;

import ac.dia.controller.exceptions.NonexistentEntityException;
import ac.dia.controller.exceptions.PreexistingEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ac.dia.model.Animal;
import ac.dia.model.Milkrecord;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author HP
 */
public class MilkrecordJpaController implements Serializable {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("dairyPU");
        EntityManager em = emf.createEntityManager();

    public MilkrecordJpaController() {
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Milkrecord milkrecord) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Animal idanimal = milkrecord.getIdanimal();
            if (idanimal != null) {
                idanimal = em.getReference(idanimal.getClass(), idanimal.getIdanimal());
                milkrecord.setIdanimal(idanimal);
            }
            em.persist(milkrecord);
            if (idanimal != null) {
                idanimal.getMilkrecordCollection().add(milkrecord);
                idanimal = em.merge(idanimal);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findMilkrecord(milkrecord.getIdmilkrecord()) != null) {
                throw new PreexistingEntityException("Milkrecord " + milkrecord + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Milkrecord milkrecord) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Milkrecord persistentMilkrecord = em.find(Milkrecord.class, milkrecord.getIdmilkrecord());
            Animal idanimalOld = persistentMilkrecord.getIdanimal();
            Animal idanimalNew = milkrecord.getIdanimal();
            if (idanimalNew != null) {
                idanimalNew = em.getReference(idanimalNew.getClass(), idanimalNew.getIdanimal());
                milkrecord.setIdanimal(idanimalNew);
            }
            milkrecord = em.merge(milkrecord);
            if (idanimalOld != null && !idanimalOld.equals(idanimalNew)) {
                idanimalOld.getMilkrecordCollection().remove(milkrecord);
                idanimalOld = em.merge(idanimalOld);
            }
            if (idanimalNew != null && !idanimalNew.equals(idanimalOld)) {
                idanimalNew.getMilkrecordCollection().add(milkrecord);
                idanimalNew = em.merge(idanimalNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = milkrecord.getIdmilkrecord();
                if (findMilkrecord(id) == null) {
                    throw new NonexistentEntityException("The milkrecord with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Milkrecord milkrecord;
            try {
                milkrecord = em.getReference(Milkrecord.class, id);
                milkrecord.getIdmilkrecord();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The milkrecord with id " + id + " no longer exists.", enfe);
            }
            Animal idanimal = milkrecord.getIdanimal();
            if (idanimal != null) {
                idanimal.getMilkrecordCollection().remove(milkrecord);
                idanimal = em.merge(idanimal);
            }
            em.remove(milkrecord);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Milkrecord> findMilkrecordEntities() {
        return findMilkrecordEntities(true, -1, -1);
    }

    public List<Milkrecord> findMilkrecordEntities(int maxResults, int firstResult) {
        return findMilkrecordEntities(false, maxResults, firstResult);
    }

    private List<Milkrecord> findMilkrecordEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Milkrecord.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Milkrecord findMilkrecord(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Milkrecord.class, id);
        } finally {
            em.close();
        }
    }

    public int getMilkrecordCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Milkrecord> rt = cq.from(Milkrecord.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
