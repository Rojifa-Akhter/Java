/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.controller;

import ac.dia.controller.exceptions.IllegalOrphanException;
import ac.dia.controller.exceptions.NonexistentEntityException;
import ac.dia.controller.exceptions.PreexistingEntityException;
import ac.dia.model.Animal;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ac.dia.model.Medical;
import java.util.ArrayList;
import java.util.Collection;
import ac.dia.model.Feed;
import ac.dia.model.Milkrecord;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author HP
 */
public class AnimalJpaController2 implements Serializable {

    public AnimalJpaController2(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Animal animal) throws PreexistingEntityException, Exception {
        if (animal.getMedicalCollection() == null) {
            animal.setMedicalCollection(new ArrayList<Medical>());
        }
        if (animal.getFeedCollection() == null) {
            animal.setFeedCollection(new ArrayList<Feed>());
        }
        if (animal.getMilkrecordCollection() == null) {
            animal.setMilkrecordCollection(new ArrayList<Milkrecord>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Medical> attachedMedicalCollection = new ArrayList<Medical>();
            for (Medical medicalCollectionMedicalToAttach : animal.getMedicalCollection()) {
                medicalCollectionMedicalToAttach = em.getReference(medicalCollectionMedicalToAttach.getClass(), medicalCollectionMedicalToAttach.getIdmedical());
                attachedMedicalCollection.add(medicalCollectionMedicalToAttach);
            }
            animal.setMedicalCollection(attachedMedicalCollection);
            Collection<Feed> attachedFeedCollection = new ArrayList<Feed>();
            for (Feed feedCollectionFeedToAttach : animal.getFeedCollection()) {
                feedCollectionFeedToAttach = em.getReference(feedCollectionFeedToAttach.getClass(), feedCollectionFeedToAttach.getIdfeed());
                attachedFeedCollection.add(feedCollectionFeedToAttach);
            }
            animal.setFeedCollection(attachedFeedCollection);
            Collection<Milkrecord> attachedMilkrecordCollection = new ArrayList<Milkrecord>();
            for (Milkrecord milkrecordCollectionMilkrecordToAttach : animal.getMilkrecordCollection()) {
                milkrecordCollectionMilkrecordToAttach = em.getReference(milkrecordCollectionMilkrecordToAttach.getClass(), milkrecordCollectionMilkrecordToAttach.getIdmilkrecord());
                attachedMilkrecordCollection.add(milkrecordCollectionMilkrecordToAttach);
            }
            animal.setMilkrecordCollection(attachedMilkrecordCollection);
            em.persist(animal);
            for (Medical medicalCollectionMedical : animal.getMedicalCollection()) {
                Animal oldIdanimalOfMedicalCollectionMedical = medicalCollectionMedical.getIdanimal();
                medicalCollectionMedical.setIdanimal(animal);
                medicalCollectionMedical = em.merge(medicalCollectionMedical);
                if (oldIdanimalOfMedicalCollectionMedical != null) {
                    oldIdanimalOfMedicalCollectionMedical.getMedicalCollection().remove(medicalCollectionMedical);
                    oldIdanimalOfMedicalCollectionMedical = em.merge(oldIdanimalOfMedicalCollectionMedical);
                }
            }
            for (Feed feedCollectionFeed : animal.getFeedCollection()) {
                Animal oldAnimalIdanimalOfFeedCollectionFeed = feedCollectionFeed.getAnimalIdanimal();
                feedCollectionFeed.setAnimalIdanimal(animal);
                feedCollectionFeed = em.merge(feedCollectionFeed);
                if (oldAnimalIdanimalOfFeedCollectionFeed != null) {
                    oldAnimalIdanimalOfFeedCollectionFeed.getFeedCollection().remove(feedCollectionFeed);
                    oldAnimalIdanimalOfFeedCollectionFeed = em.merge(oldAnimalIdanimalOfFeedCollectionFeed);
                }
            }
            for (Milkrecord milkrecordCollectionMilkrecord : animal.getMilkrecordCollection()) {
                Animal oldIdanimalOfMilkrecordCollectionMilkrecord = milkrecordCollectionMilkrecord.getIdanimal();
                milkrecordCollectionMilkrecord.setIdanimal(animal);
                milkrecordCollectionMilkrecord = em.merge(milkrecordCollectionMilkrecord);
                if (oldIdanimalOfMilkrecordCollectionMilkrecord != null) {
                    oldIdanimalOfMilkrecordCollectionMilkrecord.getMilkrecordCollection().remove(milkrecordCollectionMilkrecord);
                    oldIdanimalOfMilkrecordCollectionMilkrecord = em.merge(oldIdanimalOfMilkrecordCollectionMilkrecord);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findAnimal(animal.getIdanimal()) != null) {
                throw new PreexistingEntityException("Animal " + animal + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Animal animal) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Animal persistentAnimal = em.find(Animal.class, animal.getIdanimal());
            Collection<Medical> medicalCollectionOld = persistentAnimal.getMedicalCollection();
            Collection<Medical> medicalCollectionNew = animal.getMedicalCollection();
            Collection<Feed> feedCollectionOld = persistentAnimal.getFeedCollection();
            Collection<Feed> feedCollectionNew = animal.getFeedCollection();
            Collection<Milkrecord> milkrecordCollectionOld = persistentAnimal.getMilkrecordCollection();
            Collection<Milkrecord> milkrecordCollectionNew = animal.getMilkrecordCollection();
            List<String> illegalOrphanMessages = null;
            for (Feed feedCollectionOldFeed : feedCollectionOld) {
                if (!feedCollectionNew.contains(feedCollectionOldFeed)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Feed " + feedCollectionOldFeed + " since its animalIdanimal field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Medical> attachedMedicalCollectionNew = new ArrayList<Medical>();
            for (Medical medicalCollectionNewMedicalToAttach : medicalCollectionNew) {
                medicalCollectionNewMedicalToAttach = em.getReference(medicalCollectionNewMedicalToAttach.getClass(), medicalCollectionNewMedicalToAttach.getIdmedical());
                attachedMedicalCollectionNew.add(medicalCollectionNewMedicalToAttach);
            }
            medicalCollectionNew = attachedMedicalCollectionNew;
            animal.setMedicalCollection(medicalCollectionNew);
            Collection<Feed> attachedFeedCollectionNew = new ArrayList<Feed>();
            for (Feed feedCollectionNewFeedToAttach : feedCollectionNew) {
                feedCollectionNewFeedToAttach = em.getReference(feedCollectionNewFeedToAttach.getClass(), feedCollectionNewFeedToAttach.getIdfeed());
                attachedFeedCollectionNew.add(feedCollectionNewFeedToAttach);
            }
            feedCollectionNew = attachedFeedCollectionNew;
            animal.setFeedCollection(feedCollectionNew);
            Collection<Milkrecord> attachedMilkrecordCollectionNew = new ArrayList<Milkrecord>();
            for (Milkrecord milkrecordCollectionNewMilkrecordToAttach : milkrecordCollectionNew) {
                milkrecordCollectionNewMilkrecordToAttach = em.getReference(milkrecordCollectionNewMilkrecordToAttach.getClass(), milkrecordCollectionNewMilkrecordToAttach.getIdmilkrecord());
                attachedMilkrecordCollectionNew.add(milkrecordCollectionNewMilkrecordToAttach);
            }
            milkrecordCollectionNew = attachedMilkrecordCollectionNew;
            animal.setMilkrecordCollection(milkrecordCollectionNew);
            animal = em.merge(animal);
            for (Medical medicalCollectionOldMedical : medicalCollectionOld) {
                if (!medicalCollectionNew.contains(medicalCollectionOldMedical)) {
                    medicalCollectionOldMedical.setIdanimal(null);
                    medicalCollectionOldMedical = em.merge(medicalCollectionOldMedical);
                }
            }
            for (Medical medicalCollectionNewMedical : medicalCollectionNew) {
                if (!medicalCollectionOld.contains(medicalCollectionNewMedical)) {
                    Animal oldIdanimalOfMedicalCollectionNewMedical = medicalCollectionNewMedical.getIdanimal();
                    medicalCollectionNewMedical.setIdanimal(animal);
                    medicalCollectionNewMedical = em.merge(medicalCollectionNewMedical);
                    if (oldIdanimalOfMedicalCollectionNewMedical != null && !oldIdanimalOfMedicalCollectionNewMedical.equals(animal)) {
                        oldIdanimalOfMedicalCollectionNewMedical.getMedicalCollection().remove(medicalCollectionNewMedical);
                        oldIdanimalOfMedicalCollectionNewMedical = em.merge(oldIdanimalOfMedicalCollectionNewMedical);
                    }
                }
            }
            for (Feed feedCollectionNewFeed : feedCollectionNew) {
                if (!feedCollectionOld.contains(feedCollectionNewFeed)) {
                    Animal oldAnimalIdanimalOfFeedCollectionNewFeed = feedCollectionNewFeed.getAnimalIdanimal();
                    feedCollectionNewFeed.setAnimalIdanimal(animal);
                    feedCollectionNewFeed = em.merge(feedCollectionNewFeed);
                    if (oldAnimalIdanimalOfFeedCollectionNewFeed != null && !oldAnimalIdanimalOfFeedCollectionNewFeed.equals(animal)) {
                        oldAnimalIdanimalOfFeedCollectionNewFeed.getFeedCollection().remove(feedCollectionNewFeed);
                        oldAnimalIdanimalOfFeedCollectionNewFeed = em.merge(oldAnimalIdanimalOfFeedCollectionNewFeed);
                    }
                }
            }
            for (Milkrecord milkrecordCollectionOldMilkrecord : milkrecordCollectionOld) {
                if (!milkrecordCollectionNew.contains(milkrecordCollectionOldMilkrecord)) {
                    milkrecordCollectionOldMilkrecord.setIdanimal(null);
                    milkrecordCollectionOldMilkrecord = em.merge(milkrecordCollectionOldMilkrecord);
                }
            }
            for (Milkrecord milkrecordCollectionNewMilkrecord : milkrecordCollectionNew) {
                if (!milkrecordCollectionOld.contains(milkrecordCollectionNewMilkrecord)) {
                    Animal oldIdanimalOfMilkrecordCollectionNewMilkrecord = milkrecordCollectionNewMilkrecord.getIdanimal();
                    milkrecordCollectionNewMilkrecord.setIdanimal(animal);
                    milkrecordCollectionNewMilkrecord = em.merge(milkrecordCollectionNewMilkrecord);
                    if (oldIdanimalOfMilkrecordCollectionNewMilkrecord != null && !oldIdanimalOfMilkrecordCollectionNewMilkrecord.equals(animal)) {
                        oldIdanimalOfMilkrecordCollectionNewMilkrecord.getMilkrecordCollection().remove(milkrecordCollectionNewMilkrecord);
                        oldIdanimalOfMilkrecordCollectionNewMilkrecord = em.merge(oldIdanimalOfMilkrecordCollectionNewMilkrecord);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = animal.getIdanimal();
                if (findAnimal(id) == null) {
                    throw new NonexistentEntityException("The animal with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Animal animal;
            try {
                animal = em.getReference(Animal.class, id);
                animal.getIdanimal();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The animal with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Feed> feedCollectionOrphanCheck = animal.getFeedCollection();
            for (Feed feedCollectionOrphanCheckFeed : feedCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Animal (" + animal + ") cannot be destroyed since the Feed " + feedCollectionOrphanCheckFeed + " in its feedCollection field has a non-nullable animalIdanimal field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Medical> medicalCollection = animal.getMedicalCollection();
            for (Medical medicalCollectionMedical : medicalCollection) {
                medicalCollectionMedical.setIdanimal(null);
                medicalCollectionMedical = em.merge(medicalCollectionMedical);
            }
            Collection<Milkrecord> milkrecordCollection = animal.getMilkrecordCollection();
            for (Milkrecord milkrecordCollectionMilkrecord : milkrecordCollection) {
                milkrecordCollectionMilkrecord.setIdanimal(null);
                milkrecordCollectionMilkrecord = em.merge(milkrecordCollectionMilkrecord);
            }
            em.remove(animal);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Animal> findAnimalEntities() {
        return findAnimalEntities(true, -1, -1);
    }

    public List<Animal> findAnimalEntities(int maxResults, int firstResult) {
        return findAnimalEntities(false, maxResults, firstResult);
    }

    private List<Animal> findAnimalEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Animal.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Animal findAnimal(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Animal.class, id);
        } finally {
            em.close();
        }
    }

    public int getAnimalCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Animal> rt = cq.from(Animal.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
