/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.controller;

import ac.dia.controller.exceptions.NonexistentEntityException;
import ac.dia.controller.exceptions.PreexistingEntityException;
import ac.dia.model.Dailyincome;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author HP
 */
public class DailyincomeJpaController implements Serializable {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("dairyPU");
        EntityManager em = emf.createEntityManager();

    public DailyincomeJpaController() {
        
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Dailyincome dailyincome) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(dailyincome);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findDailyincome(dailyincome.getIddailyIncome()) != null) {
                throw new PreexistingEntityException("Dailyincome " + dailyincome + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Dailyincome dailyincome) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            dailyincome = em.merge(dailyincome);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = dailyincome.getIddailyIncome();
                if (findDailyincome(id) == null) {
                    throw new NonexistentEntityException("The dailyincome with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Dailyincome dailyincome;
            try {
                dailyincome = em.getReference(Dailyincome.class, id);
                dailyincome.getIddailyIncome();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The dailyincome with id " + id + " no longer exists.", enfe);
            }
            em.remove(dailyincome);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Dailyincome> findDailyincomeEntities() {
        return findDailyincomeEntities(true, -1, -1);
    }

    public List<Dailyincome> findDailyincomeEntities(int maxResults, int firstResult) {
        return findDailyincomeEntities(false, maxResults, firstResult);
    }

    private List<Dailyincome> findDailyincomeEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Dailyincome.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Dailyincome findDailyincome(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Dailyincome.class, id);
        } finally {
            em.close();
        }
    }

    public int getDailyincomeCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Dailyincome> rt = cq.from(Dailyincome.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
