/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.controller;

import ac.dia.controller.exceptions.NonexistentEntityException;
import ac.dia.controller.exceptions.PreexistingEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ac.dia.model.Animal;
import ac.dia.model.Feed;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author HP
 */
public class FeedJpaController implements Serializable {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("dairyPU");
        EntityManager em = emf.createEntityManager();

    public FeedJpaController() {
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Feed feed) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Animal animalIdanimal = feed.getAnimalIdanimal();
            if (animalIdanimal != null) {
                animalIdanimal = em.getReference(animalIdanimal.getClass(), animalIdanimal.getIdanimal());
                feed.setAnimalIdanimal(animalIdanimal);
            }
            em.persist(feed);
            if (animalIdanimal != null) {
                animalIdanimal.getFeedCollection().add(feed);
                animalIdanimal = em.merge(animalIdanimal);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findFeed(feed.getIdfeed()) != null) {
                throw new PreexistingEntityException("Feed " + feed + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Feed feed) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Feed persistentFeed = em.find(Feed.class, feed.getIdfeed());
            Animal animalIdanimalOld = persistentFeed.getAnimalIdanimal();
            Animal animalIdanimalNew = feed.getAnimalIdanimal();
            if (animalIdanimalNew != null) {
                animalIdanimalNew = em.getReference(animalIdanimalNew.getClass(), animalIdanimalNew.getIdanimal());
                feed.setAnimalIdanimal(animalIdanimalNew);
            }
            feed = em.merge(feed);
            if (animalIdanimalOld != null && !animalIdanimalOld.equals(animalIdanimalNew)) {
                animalIdanimalOld.getFeedCollection().remove(feed);
                animalIdanimalOld = em.merge(animalIdanimalOld);
            }
            if (animalIdanimalNew != null && !animalIdanimalNew.equals(animalIdanimalOld)) {
                animalIdanimalNew.getFeedCollection().add(feed);
                animalIdanimalNew = em.merge(animalIdanimalNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = feed.getIdfeed();
                if (findFeed(id) == null) {
                    throw new NonexistentEntityException("The feed with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Feed feed;
            try {
                feed = em.getReference(Feed.class, id);
                feed.getIdfeed();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The feed with id " + id + " no longer exists.", enfe);
            }
            Animal animalIdanimal = feed.getAnimalIdanimal();
            if (animalIdanimal != null) {
                animalIdanimal.getFeedCollection().remove(feed);
                animalIdanimal = em.merge(animalIdanimal);
            }
            em.remove(feed);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Feed> findFeedEntities() {
        return findFeedEntities(true, -1, -1);
    }

    public List<Feed> findFeedEntities(int maxResults, int firstResult) {
        return findFeedEntities(false, maxResults, firstResult);
    }

    private List<Feed> findFeedEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Feed.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Feed findFeed(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Feed.class, id);
        } finally {
            em.close();
        }
    }

    public int getFeedCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Feed> rt = cq.from(Feed.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
