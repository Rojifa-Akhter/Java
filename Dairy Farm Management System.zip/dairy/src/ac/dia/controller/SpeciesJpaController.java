/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.controller;

import ac.dia.controller.exceptions.NonexistentEntityException;
import ac.dia.controller.exceptions.PreexistingEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ac.dia.model.Animaltype;
import ac.dia.model.Species;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author HP
 */
public class SpeciesJpaController implements Serializable {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("dairyPU");
        EntityManager em = emf.createEntityManager();

    public SpeciesJpaController() {
        
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Species species) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Animaltype idanimalType = species.getIdanimalType();
            if (idanimalType != null) {
                idanimalType = em.getReference(idanimalType.getClass(), idanimalType.getIdanimalType());
                species.setIdanimalType(idanimalType);
            }
            em.persist(species);
            if (idanimalType != null) {
                idanimalType.getSpeciesCollection().add(species);
                idanimalType = em.merge(idanimalType);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findSpecies(species.getIdspecies()) != null) {
                throw new PreexistingEntityException("Species " + species + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Species species) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Species persistentSpecies = em.find(Species.class, species.getIdspecies());
            Animaltype idanimalTypeOld = persistentSpecies.getIdanimalType();
            Animaltype idanimalTypeNew = species.getIdanimalType();
            if (idanimalTypeNew != null) {
                idanimalTypeNew = em.getReference(idanimalTypeNew.getClass(), idanimalTypeNew.getIdanimalType());
                species.setIdanimalType(idanimalTypeNew);
            }
            species = em.merge(species);
            if (idanimalTypeOld != null && !idanimalTypeOld.equals(idanimalTypeNew)) {
                idanimalTypeOld.getSpeciesCollection().remove(species);
                idanimalTypeOld = em.merge(idanimalTypeOld);
            }
            if (idanimalTypeNew != null && !idanimalTypeNew.equals(idanimalTypeOld)) {
                idanimalTypeNew.getSpeciesCollection().add(species);
                idanimalTypeNew = em.merge(idanimalTypeNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = species.getIdspecies();
                if (findSpecies(id) == null) {
                    throw new NonexistentEntityException("The species with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Species species;
            try {
                species = em.getReference(Species.class, id);
                species.getIdspecies();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The species with id " + id + " no longer exists.", enfe);
            }
            Animaltype idanimalType = species.getIdanimalType();
            if (idanimalType != null) {
                idanimalType.getSpeciesCollection().remove(species);
                idanimalType = em.merge(idanimalType);
            }
            em.remove(species);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Species> findSpeciesEntities() {
        return findSpeciesEntities(true, -1, -1);
    }

    public List<Species> findSpeciesEntities(int maxResults, int firstResult) {
        return findSpeciesEntities(false, maxResults, firstResult);
    }

    private List<Species> findSpeciesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Species.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Species findSpecies(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Species.class, id);
        } finally {
            em.close();
        }
    }

    public int getSpeciesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Species> rt = cq.from(Species.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
