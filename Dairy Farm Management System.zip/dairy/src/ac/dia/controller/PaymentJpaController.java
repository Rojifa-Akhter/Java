/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.dia.controller;

import ac.dia.controller.exceptions.NonexistentEntityException;
import ac.dia.controller.exceptions.PreexistingEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import ac.dia.model.Customer;
import ac.dia.model.Payment;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author HP
 */
public class PaymentJpaController implements Serializable {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("dairyPU");
        EntityManager em = emf.createEntityManager();

    public PaymentJpaController() {
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Payment payment) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Customer customerIdcustomer = payment.getCustomerIdcustomer();
            if (customerIdcustomer != null) {
                customerIdcustomer = em.getReference(customerIdcustomer.getClass(), customerIdcustomer.getIdcustomer());
                payment.setCustomerIdcustomer(customerIdcustomer);
            }
            em.persist(payment);
            if (customerIdcustomer != null) {
                customerIdcustomer.getPaymentCollection().add(payment);
                customerIdcustomer = em.merge(customerIdcustomer);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findPayment(payment.getIdpayment()) != null) {
                throw new PreexistingEntityException("Payment " + payment + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Payment payment) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Payment persistentPayment = em.find(Payment.class, payment.getIdpayment());
            Customer customerIdcustomerOld = persistentPayment.getCustomerIdcustomer();
            Customer customerIdcustomerNew = payment.getCustomerIdcustomer();
            if (customerIdcustomerNew != null) {
                customerIdcustomerNew = em.getReference(customerIdcustomerNew.getClass(), customerIdcustomerNew.getIdcustomer());
                payment.setCustomerIdcustomer(customerIdcustomerNew);
            }
            payment = em.merge(payment);
            if (customerIdcustomerOld != null && !customerIdcustomerOld.equals(customerIdcustomerNew)) {
                customerIdcustomerOld.getPaymentCollection().remove(payment);
                customerIdcustomerOld = em.merge(customerIdcustomerOld);
            }
            if (customerIdcustomerNew != null && !customerIdcustomerNew.equals(customerIdcustomerOld)) {
                customerIdcustomerNew.getPaymentCollection().add(payment);
                customerIdcustomerNew = em.merge(customerIdcustomerNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = payment.getIdpayment();
                if (findPayment(id) == null) {
                    throw new NonexistentEntityException("The payment with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Payment payment;
            try {
                payment = em.getReference(Payment.class, id);
                payment.getIdpayment();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The payment with id " + id + " no longer exists.", enfe);
            }
            Customer customerIdcustomer = payment.getCustomerIdcustomer();
            if (customerIdcustomer != null) {
                customerIdcustomer.getPaymentCollection().remove(payment);
                customerIdcustomer = em.merge(customerIdcustomer);
            }
            em.remove(payment);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Payment> findPaymentEntities() {
        return findPaymentEntities(true, -1, -1);
    }

    public List<Payment> findPaymentEntities(int maxResults, int firstResult) {
        return findPaymentEntities(false, maxResults, firstResult);
    }

    private List<Payment> findPaymentEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Payment.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Payment findPayment(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Payment.class, id);
        } finally {
            em.close();
        }
    }

    public int getPaymentCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Payment> rt = cq.from(Payment.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
