package ac.dia.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseUtil {
	DBUtil bd=new DBUtil();
	
	public int DML(String sql) throws ClassNotFoundException, SQLException {
	 return	bd.getConnection().createStatement().executeUpdate(sql);
		
	}
	
	public ResultSet select(String sql) throws ClassNotFoundException, SQLException {
		return bd.getConnection().createStatement().executeQuery(sql);
	 	
	}

}
