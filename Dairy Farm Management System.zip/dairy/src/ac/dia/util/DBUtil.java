package ac.dia.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url = "jdbc:mysql://localhost:3306/dairy";
	private String user = "root";
	private String password = "root";
	private static Connection con;

	public void load() throws ClassNotFoundException {
		// TODO Auto-generated method stub
		Class.forName(driver);
	}

	public Connection getConnection() throws SQLException, ClassNotFoundException {
		load();
		con = DriverManager.getConnection(url, user, password);
		return con;

	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
